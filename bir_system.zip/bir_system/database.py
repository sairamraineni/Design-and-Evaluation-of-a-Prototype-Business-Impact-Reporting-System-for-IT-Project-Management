"""
database.py
-----------
Database connection manager using Python's built-in sqlite3.
Handles connection lifecycle, schema creation, and query helpers.
"""

import sqlite3
import os
from contextlib import contextmanager
from pathlib import Path

DB_PATH = os.environ.get("BIR_DB_PATH", "bir_system.db")
SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def get_connection(db_path: str = DB_PATH) -> sqlite3.Connection:
    """Return a sqlite3 connection with row_factory set for dict-like access."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


@contextmanager
def managed_connection(db_path: str = DB_PATH):
    """Context manager: auto-commits on success, rolls back on error."""
    conn = get_connection(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def initialise_db(db_path: str = DB_PATH, schema_path: Path = SCHEMA_PATH) -> None:
    """Create all tables and seed KPI/mapping data from schema.sql."""
    if not schema_path.exists():
        raise FileNotFoundError(f"Schema file not found: {schema_path}")
    sql = schema_path.read_text()
    with managed_connection(db_path) as conn:
        conn.executescript(sql)
    print(f"[DB] Initialised: {db_path}")


def fetchall(sql: str, params: tuple = (), db_path: str = DB_PATH) -> list[dict]:
    """Run a SELECT and return all rows as plain dicts."""
    with managed_connection(db_path) as conn:
        cur = conn.execute(sql, params)
        return [dict(row) for row in cur.fetchall()]


def fetchone(sql: str, params: tuple = (), db_path: str = DB_PATH) -> dict | None:
    """Run a SELECT and return the first row as a plain dict, or None."""
    with managed_connection(db_path) as conn:
        cur = conn.execute(sql, params)
        row = cur.fetchone()
        return dict(row) if row else None


def execute(sql: str, params: tuple = (), db_path: str = DB_PATH) -> int:
    """Run an INSERT/UPDATE/DELETE and return lastrowid."""
    with managed_connection(db_path) as conn:
        cur = conn.execute(sql, params)
        return cur.lastrowid


def executemany(sql: str, data: list[tuple], db_path: str = DB_PATH) -> None:
    """Bulk INSERT/UPDATE using executemany for efficiency."""
    with managed_connection(db_path) as conn:
        conn.executemany(sql, data)


# ---------------------------------------------------------------------------
# CRUD helpers
# ---------------------------------------------------------------------------

class ProjectDAO:
    """Data Access Object for the projects table."""

    @staticmethod
    def get_all() -> list[dict]:
        return fetchall("SELECT * FROM projects ORDER BY created_at DESC")

    @staticmethod
    def get_by_id(project_id: int) -> dict | None:
        return fetchone("SELECT * FROM projects WHERE project_id = ?", (project_id,))

    @staticmethod
    def create(name: str, description: str, start_date: str, end_date: str,
               project_manager: str, budget: float = 0.0, status: str = "active") -> int:
        return execute(
            """INSERT INTO projects
               (project_name, description, start_date, end_date, status, project_manager, budget)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (name, description, start_date, end_date, status, project_manager, budget)
        )

    @staticmethod
    def update_status(project_id: int, status: str) -> None:
        execute("UPDATE projects SET status = ? WHERE project_id = ?", (status, project_id))


class TaskDAO:
    @staticmethod
    def get_by_project(project_id: int) -> list[dict]:
        return fetchall("SELECT * FROM tasks WHERE project_id = ? ORDER BY planned_start", (project_id,))

    @staticmethod
    def create(project_id: int, task_name: str, planned_start: str, planned_end: str,
               actual_start: str = None, actual_end: str = None,
               completion_pct: float = 0.0, status: str = "not_started",
               milestone: int = 0) -> int:
        return execute(
            """INSERT INTO tasks
               (project_id, task_name, planned_start, planned_end, actual_start,
                actual_end, completion_pct, status, milestone)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (project_id, task_name, planned_start, planned_end,
             actual_start, actual_end, completion_pct, status, milestone)
        )


class MetricDAO:
    @staticmethod
    def get_by_project(project_id: int) -> list[dict]:
        return fetchall(
            "SELECT * FROM technical_metrics WHERE project_id = ? ORDER BY recorded_at DESC",
            (project_id,)
        )

    @staticmethod
    def get_latest_per_name(project_id: int) -> dict[str, float]:
        """Return the most recent value for each metric name as a flat dict."""
        rows = fetchall(
            """SELECT metric_name, metric_value
               FROM technical_metrics
               WHERE project_id = ?
               AND recorded_at = (
                   SELECT MAX(recorded_at) FROM technical_metrics t2
                   WHERE t2.project_id = technical_metrics.project_id
                   AND t2.metric_name = technical_metrics.metric_name
               )""",
            (project_id,)
        )
        return {r["metric_name"]: r["metric_value"] for r in rows}

    @staticmethod
    def insert(project_id: int, metric_name: str, metric_value: float,
               unit: str = "", source: str = "manual") -> int:
        return execute(
            """INSERT INTO technical_metrics
               (project_id, metric_name, metric_value, unit, source)
               VALUES (?, ?, ?, ?, ?)""",
            (project_id, metric_name, metric_value, unit, source)
        )


class RiskDAO:
    @staticmethod
    def get_by_project(project_id: int) -> list[dict]:
        return fetchall(
            "SELECT * FROM risks WHERE project_id = ? ORDER BY impact DESC, probability DESC",
            (project_id,)
        )

    @staticmethod
    def create(project_id: int, description: str, probability: str = "medium",
               impact: str = "medium", mitigation_plan: str = "") -> int:
        return execute(
            """INSERT INTO risks
               (project_id, description, probability, impact, mitigation_plan)
               VALUES (?, ?, ?, ?, ?)""",
            (project_id, description, probability, impact, mitigation_plan)
        )


class KpiDAO:
    @staticmethod
    def get_all() -> list[dict]:
        return fetchall("SELECT * FROM kpis ORDER BY category, kpi_name")

    @staticmethod
    def get_mapping_rules() -> list[dict]:
        return fetchall(
            """SELECT m.*, k.kpi_name, k.category, k.unit, k.target_value, k.higher_is_better
               FROM metric_kpi_mapping m
               JOIN kpis k ON k.kpi_id = m.kpi_id"""
        )


class ReportDAO:
    @staticmethod
    def create(project_id: int, report_type: str, generated_by: str) -> int:
        return execute(
            """INSERT INTO reports (project_id, report_type, generated_by)
               VALUES (?, ?, ?)""",
            (project_id, report_type, generated_by)
        )

    @staticmethod
    def save_kpi_values(report_id: int, kpi_values: list[dict]) -> None:
        executemany(
            """INSERT INTO report_kpi_values
               (report_id, kpi_id, computed_value, target_value, status, notes)
               VALUES (:report_id, :kpi_id, :computed_value, :target_value, :status, :notes)""",
            [{**v, "report_id": report_id} for v in kpi_values]
        )

    @staticmethod
    def get_latest_for_project(project_id: int) -> dict | None:
        return fetchone(
            """SELECT r.*, GROUP_CONCAT(k.kpi_name) as kpi_names
               FROM reports r
               LEFT JOIN report_kpi_values rkv ON rkv.report_id = r.report_id
               LEFT JOIN kpis k ON k.kpi_id = rkv.kpi_id
               WHERE r.project_id = ?
               ORDER BY r.generated_at DESC LIMIT 1""",
            (project_id,)
        )

    @staticmethod
    def get_kpi_values_for_report(report_id: int) -> list[dict]:
        return fetchall(
            """SELECT rkv.*, k.kpi_name, k.category, k.unit, k.higher_is_better
               FROM report_kpi_values rkv
               JOIN kpis k ON k.kpi_id = rkv.kpi_id
               WHERE rkv.report_id = ?
               ORDER BY k.category, k.kpi_name""",
            (report_id,)
        )
