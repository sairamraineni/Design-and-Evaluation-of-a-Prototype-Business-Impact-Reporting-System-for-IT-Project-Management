"""
app.py
------
Streamlit dashboard for the Business-Impact Reporting System.

Run with:
    streamlit run app.py

First-time setup:
    pip install -r requirements.txt
    python seeder.py --reset
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px

from database import ProjectDAO, TaskDAO, RiskDAO, MetricDAO, initialise_db, DB_PATH
from engine.kpi_engine import KPIEngine, ProjectScorecard
from engine.report_generator import ReportBuilder
from seeder import seed_all

# ---------------------------------------------------------------------------
# Page config
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Business-Impact Reporting System",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------------------------
# Initialise DB on first run
# ---------------------------------------------------------------------------
if not os.path.exists(DB_PATH):
    seed_all(reset=True)

# ---------------------------------------------------------------------------
# Custom CSS
# ---------------------------------------------------------------------------
st.markdown("""
<style>
  .metric-card {
    background: #f9f9f7; border: 1px solid #e8e6dc;
    border-radius: 10px; padding: 16px; text-align: center;
  }
  .metric-card .label { font-size: 11px; color: #888780; text-transform: uppercase;
                         letter-spacing: .06em; margin-bottom: 6px; }
  .metric-card .value { font-size: 28px; font-weight: 600; }
  .badge-green  { background:#EAF3DE; color:#3B6D11; padding:3px 10px; border-radius:20px;
                   font-size:11px; font-weight:600; }
  .badge-amber  { background:#FAEEDA; color:#854F0B; padding:3px 10px; border-radius:20px;
                   font-size:11px; font-weight:600; }
  .badge-red    { background:#FCEBEB; color:#A32D2D; padding:3px 10px; border-radius:20px;
                   font-size:11px; font-weight:600; }
  .badge-blue   { background:#E6F1FB; color:#0C447C; padding:3px 10px; border-radius:20px;
                   font-size:11px; font-weight:600; }
  div[data-testid="stSidebarContent"] { padding-top: 1rem; }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
st.sidebar.title("📊 BIR System")
st.sidebar.caption("Business-Impact Reporting")

projects = ProjectDAO.get_all()
if not projects:
    st.warning("No projects found. Click 'Reseed database' below.")
    if st.button("Reseed database"):
        seed_all(reset=True)
        st.rerun()
    st.stop()

project_names = {p["project_id"]: p["project_name"] for p in projects}
selected_id   = st.sidebar.selectbox(
    "Select project",
    options=list(project_names.keys()),
    format_func=lambda x: project_names[x],
)

project = ProjectDAO.get_by_id(selected_id)
st.sidebar.divider()
st.sidebar.caption(f"**Manager:** {project['project_manager']}")
st.sidebar.caption(f"**Start:** {project['start_date']}")
st.sidebar.caption(f"**End:** {project['end_date']}")
st.sidebar.caption(f"**Budget:** £{project['budget']:,.0f}")
st.sidebar.divider()

report_type = st.sidebar.radio("Report mode", ["business_impact", "technical"],
                                format_func=lambda x: x.replace("_", " ").title())
gen_by = st.sidebar.text_input("Report author", value="System")

if st.sidebar.button("⬇ Generate & download report", use_container_width=True):
    with st.spinner("Building report..."):
        builder = ReportBuilder()
        html = builder.build(selected_id, report_type=report_type, generated_by=gen_by)
    st.sidebar.download_button(
        label="Download HTML report",
        data=html,
        file_name=f"report_{selected_id}_{report_type}.html",
        mime="text/html",
        use_container_width=True,
    )

st.sidebar.divider()
if st.sidebar.button("🔄 Reseed database", use_container_width=True):
    seed_all(reset=True)
    st.rerun()

# ---------------------------------------------------------------------------
# Main content
# ---------------------------------------------------------------------------
STATUS_COLOR = {"on_track": "#1D9E75", "at_risk": "#BA7517", "off_track": "#E24B4A"}
STATUS_BG    = {"on_track": "#EAF3DE", "at_risk": "#FAEEDA", "off_track": "#FCEBEB"}
STATUS_LABEL = {"on_track": "On track", "at_risk": "At risk",  "off_track": "Off track"}

@st.cache_data(ttl=30)
def get_scorecard(project_id: int) -> ProjectScorecard:
    return KPIEngine().compute(project_id)

scorecard = get_scorecard(selected_id)
tasks     = TaskDAO.get_by_project(selected_id)
risks     = RiskDAO.get_by_project(selected_id)
metrics   = MetricDAO.get_latest_per_name(selected_id)

# Header
col_title, col_status = st.columns([3, 1])
with col_title:
    st.title(project["project_name"])
    st.caption(project.get("description", ""))
with col_status:
    st.markdown("<br>", unsafe_allow_html=True)
    oc = scorecard.overall_status
    st.markdown(
        f'<div style="text-align:right">'
        f'<span style="background:{STATUS_BG[oc]};color:{STATUS_COLOR[oc]};'
        f'padding:6px 16px;border-radius:20px;font-weight:600;font-size:13px">'
        f'Overall: {STATUS_LABEL[oc]}</span></div>',
        unsafe_allow_html=True
    )

st.divider()

# ---------------------------------------------------------------------------
# Summary stat cards
# ---------------------------------------------------------------------------
milestones    = [t for t in tasks if t["milestone"]]
completed_ms  = sum(1 for m in milestones if m["status"] == "completed")
open_risks    = sum(1 for r in risks if r["status"] == "open")

c1, c2, c3, c4 = st.columns(4)
for col, label, val, color in [
    (c1, "Project health",    f"{scorecard.health_pct}%",     STATUS_COLOR[scorecard.overall_status]),
    (c2, "Milestones done",   f"{completed_ms}/{len(milestones)}", "#378ADD"),
    (c3, "Open risks",        str(open_risks),                "#E24B4A" if open_risks > 2 else "#BA7517"),
    (c4, "Risk exposure",     str(scorecard.risk_exposure_score), STATUS_COLOR[scorecard.overall_status]),
]:
    col.markdown(
        f'<div class="metric-card">'
        f'<div class="label">{label}</div>'
        f'<div class="value" style="color:{color}">{val}</div>'
        f'</div>',
        unsafe_allow_html=True
    )

st.markdown("<br>", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Tabs
# ---------------------------------------------------------------------------
tab1, tab2, tab3, tab4 = st.tabs(["📈 KPI Dashboard", "✅ Tasks", "⚠ Risks", "🔬 Raw Metrics"])

# ── Tab 1: KPI Dashboard ──────────────────────────────────────────────────
with tab1:
    left, right = st.columns([3, 2])

    with left:
        st.subheader("KPI performance vs target")
        kpi_names  = [s.kpi_name for s in scorecard.kpi_scores]
        kpi_vals   = [s.computed_value for s in scorecard.kpi_scores]
        kpi_tgts   = [s.target_value   for s in scorecard.kpi_scores]
        kpi_colors = [STATUS_COLOR[s.status] for s in scorecard.kpi_scores]

        fig = go.Figure()
        fig.add_trace(go.Bar(
            name="Target", x=kpi_tgts, y=kpi_names, orientation="h",
            marker_color="rgba(0,0,0,0.06)", hoverinfo="skip"
        ))
        fig.add_trace(go.Bar(
            name="Achieved", x=kpi_vals, y=kpi_names, orientation="h",
            marker_color=kpi_colors,
            text=[f"{v:.2f}" for v in kpi_vals],
            textposition="inside", insidetextanchor="start",
            textfont=dict(color="white", size=11),
        ))
        fig.update_layout(
            barmode="overlay", height=320,
            margin=dict(l=0, r=20, t=10, b=30),
            plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
            legend=dict(orientation="h", y=-0.2, font_size=11),
            xaxis=dict(gridcolor="rgba(0,0,0,0.06)", zeroline=False, showline=False),
            yaxis=dict(automargin=True),
            font=dict(size=11),
        )
        st.plotly_chart(fig, use_container_width=True)

    with right:
        st.subheader("Status breakdown")
        labels = ["On track", "At risk", "Off track"]
        values = [scorecard.on_track_count, scorecard.at_risk_count, scorecard.off_track_count]
        colors = ["#1D9E75", "#BA7517", "#E24B4A"]
        pie = go.Figure(go.Pie(
            labels=labels, values=values, marker_colors=colors,
            hole=0.55, textinfo="label+value",
            textfont_size=12,
        ))
        pie.update_layout(
            height=260, margin=dict(l=10, r=10, t=10, b=10),
            paper_bgcolor="rgba(0,0,0,0)", showlegend=False
        )
        st.plotly_chart(pie, use_container_width=True)

        st.subheader("KPI scores")
        for score in scorecard.kpi_scores:
            badge_class = {"on_track": "badge-green", "at_risk": "badge-amber",
                           "off_track": "badge-red"}.get(score.status, "badge-blue")
            st.markdown(
                f'<div style="display:flex;justify-content:space-between;'
                f'align-items:center;padding:5px 0;border-bottom:1px solid #f0ede6">'
                f'<span style="font-size:12px">{score.kpi_name}</span>'
                f'<span class="{badge_class}">{score.computed_value:.2f}</span>'
                f'</div>',
                unsafe_allow_html=True
            )

# ── Tab 2: Tasks ──────────────────────────────────────────────────────────
with tab2:
    st.subheader("Task list")
    for task in tasks:
        with st.expander(
            f"{'⭐ ' if task['milestone'] else ''}{task['task_name']} — {task['status'].replace('_',' ').title()}",
            expanded=False
        ):
            c1, c2, c3 = st.columns(3)
            c1.metric("Completion", f"{task['completion_pct']:.0f}%")
            c2.metric("Planned start", task["planned_start"])
            c3.metric("Planned end",   task["planned_end"])
            prog = task["completion_pct"] / 100
            st.progress(prog)
            if task["actual_start"]:
                st.caption(f"Actual start: {task['actual_start']}")
            if task["actual_end"]:
                st.caption(f"Actual end: {task['actual_end']}")

# ── Tab 3: Risks ──────────────────────────────────────────────────────────
with tab3:
    st.subheader("Risk register")
    impact_filter = st.multiselect(
        "Filter by impact", ["high", "medium", "low"], default=["high", "medium", "low"]
    )
    filtered_risks = [r for r in risks if r["impact"] in impact_filter]

    for risk in filtered_risks:
        imp = risk["impact"]
        col = {"high": "#A32D2D", "medium": "#854F0B", "low": "#3B6D11"}.get(imp, "#888")
        bg  = {"high": "#FCEBEB", "medium": "#FAEEDA", "low": "#EAF3DE"}.get(imp, "#f5f5f5")
        with st.expander(f"{risk['description'][:80]}...", expanded=False):
            c1, c2, c3 = st.columns(3)
            c1.markdown(f"**Impact:** <span style='color:{col}'>{imp.capitalize()}</span>", unsafe_allow_html=True)
            c2.markdown(f"**Probability:** {risk['probability'].capitalize()}")
            c3.markdown(f"**Status:** {risk['status'].capitalize()}")
            if risk.get("mitigation_plan"):
                st.info(f"**Mitigation:** {risk['mitigation_plan']}")

# ── Tab 4: Raw Metrics ────────────────────────────────────────────────────
with tab4:
    st.subheader("Raw technical metrics")
    st.caption("Direct values from project tools — no KPI translation applied.")

    if metrics:
        m_names = list(metrics.keys())
        m_vals  = list(metrics.values())
        bar = px.bar(
            x=m_vals, y=m_names, orientation="h",
            labels={"x": "Value", "y": "Metric"},
            color=m_vals, color_continuous_scale=["#E6F1FB", "#378ADD", "#0C447C"],
        )
        bar.update_layout(
            height=320, margin=dict(l=0, r=20, t=10, b=20),
            plot_bgcolor="rgba(0,0,0,0)", paper_bgcolor="rgba(0,0,0,0)",
            coloraxis_showscale=False, font=dict(size=11),
            yaxis=dict(automargin=True),
        )
        st.plotly_chart(bar, use_container_width=True)

        st.subheader("Metric values")
        for name, value in metrics.items():
            st.markdown(
                f'<div style="display:flex;justify-content:space-between;padding:5px 0;'
                f'border-bottom:1px solid #f0ede6">'
                f'<code style="font-size:12px">{name}</code>'
                f'<strong>{value}</strong></div>',
                unsafe_allow_html=True
            )
    else:
        st.info("No metric data found for this project.")
