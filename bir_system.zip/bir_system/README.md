# Business-Impact Reporting System
**Edinburgh Napier University — MSc Dissertation**
*Design and Evaluation of a Prototype Business-Impact Reporting System for IT Project Management*

---

## Project structure

```
bir_system/
├── app.py                    # Streamlit dashboard (Phase 4)
├── database.py               # DB connection manager + DAO classes (Phase 2)
├── seeder.py                 # Simulated data seeder (Phase 2)
├── schema.sql                # Full database schema (Phase 1)
├── requirements.txt
├── engine/
│   ├── mapping_engine.py     # MetricMapper — metrics → KPIs (Phase 3)
│   ├── kpi_engine.py         # KPI computation + scoring (Phase 3)
│   └── report_generator.py  # ReportBuilder — HTML/PDF output (Phase 5)
└── templates/
    ├── report_business.html  # Business impact report template
    └── report_technical.html # Technical comparison report template
```

---

## Quick start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Initialise and seed the database
```bash
python seeder.py --reset
```
This creates `bir_system.db` with 3 sample projects, tasks, risks, resources and metrics.

### 3. Run the dashboard
```bash
streamlit run app.py
```
Open http://localhost:8501 in your browser.

---

## Generating reports from the command line

```python
from database import initialise_db
from engine.report_generator import ReportBuilder

builder = ReportBuilder()

# Business impact report (for stakeholders)
html = builder.build(project_id=1, report_type="business_impact", generated_by="Jane Smith")
builder.save_html(html, "output/report_business.html")

# Technical report (for comparison in dissertation evaluation)
html = builder.build(project_id=1, report_type="technical", generated_by="Jane Smith")
builder.save_html(html, "output/report_technical.html")

# PDF export (requires WeasyPrint)
builder.save_pdf(html, "output/report_technical.pdf")
```

---

## Architecture overview

```
Input sources (Jira / CI / manual)
        ↓
  Data ingestion layer
        ↓
  SQLite database  ←──── schema.sql
        ↓         ↘
  Mapping engine   Risk analyser
  (MetricMapper)
        ↓
  KPI computation engine
  (KPIEngine)
        ↓
  Report generator
  (ReportBuilder)
        ↓         ↘
  Dashboard UI    PDF/HTML export
  (Streamlit)
```

---

## Research question mapping

| Research question | Implementation |
|---|---|
| RQ1: How are technical metrics mapped to business KPIs? | `engine/mapping_engine.py` — `MetricMapper` reads rules from `metric_kpi_mapping` table |
| RQ2: How does the DB support traceability? | `schema.sql` — `tasks → projects → reports → report_kpi_values` chain |
| RQ3: How does business reporting compare to technical? | Two report templates + side-by-side comparison via `report_type` flag |

---

## Extending the system

### Add a new KPI
```sql
INSERT INTO kpis (kpi_name, description, category, unit, target_value, higher_is_better)
VALUES ('Deployment Frequency', 'Releases per sprint', 'quality', 'count', 2.0, 1);
```

### Add a mapping rule
```sql
INSERT INTO metric_kpi_mapping (metric_name, kpi_id, formula, weight)
VALUES ('deployments_per_sprint', <kpi_id>, 'value', 1.0);
```

### Ingest a new metric
```python
from database import MetricDAO
MetricDAO.insert(project_id=1, metric_name="deployments_per_sprint",
                 metric_value=3.0, unit="count", source="CI Pipeline")
```

---

## Tech stack

| Component | Technology |
|---|---|
| Database | SQLite 3 (built-in) |
| Data layer | Python `sqlite3`, dataclasses |
| Mapping engine | Python OOP (`MetricMapper`) |
| Dashboard | Streamlit + Plotly |
| Reports | Jinja2 HTML templates |
| PDF export | WeasyPrint |
