"""
engine/kpi_engine.py
--------------------
KPI computation engine: aggregates weighted MappedValues into final KPI scores,
applies threshold logic to determine on_track / at_risk / off_track status,
and produces a full project scorecard.
"""

from __future__ import annotations
from dataclasses import dataclass
from engine.mapping_engine import MetricMapper, MappedValue
from database import KpiDAO, RiskDAO


# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------

# For higher_is_better KPIs (e.g. test coverage, milestone rate):
#   score >= GREEN_HIGH  → on_track
#   score >= AMBER_HIGH  → at_risk
#   else                 → off_track

# For lower_is_better KPIs (e.g. budget utilisation, resource ratio):
#   score <= GREEN_LOW   → on_track
#   score <= AMBER_LOW   → at_risk
#   else                 → off_track

THRESHOLDS = {
    "higher": {"green": 0.90, "amber": 0.70},  # 90%+ of target = green
    "lower":  {"green": 1.05, "amber": 1.20},  # within 5% over = green
}

RISK_WEIGHTS = {"high": 3.0, "medium": 1.0, "low": 0.3}


# ---------------------------------------------------------------------------
# Result dataclasses
# ---------------------------------------------------------------------------

@dataclass
class KPIScore:
    kpi_id: int
    kpi_name: str
    category: str
    computed_value: float
    target_value: float
    unit: str
    status: str                   # on_track | at_risk | off_track
    higher_is_better: int
    contributing_metrics: list[str]
    notes: str = ""

    @property
    def status_color(self) -> str:
        return {"on_track": "green", "at_risk": "amber", "off_track": "red"}.get(self.status, "gray")

    @property
    def pct_of_target(self) -> float:
        if self.target_value == 0:
            return 100.0
        return round(self.computed_value / self.target_value * 100, 1)


@dataclass
class ProjectScorecard:
    project_id: int
    kpi_scores: list[KPIScore]
    overall_status: str
    on_track_count: int
    at_risk_count: int
    off_track_count: int
    risk_exposure_score: float

    @property
    def health_pct(self) -> float:
        total = len(self.kpi_scores)
        if total == 0:
            return 0.0
        return round(self.on_track_count / total * 100, 1)


# ---------------------------------------------------------------------------
# KPI Engine
# ---------------------------------------------------------------------------

class KPIEngine:
    """
    Aggregates MappedValues from MetricMapper into final KPI scores.

    Steps:
      1. Group MappedValues by KPI
      2. Compute weighted average contribution per KPI
      3. Apply threshold logic to assign status
      4. Add risk exposure KPI from risk register
      5. Return ProjectScorecard
    """

    def __init__(self):
        self._mapper = MetricMapper()
        self._kpis   = {k["kpi_id"]: k for k in KpiDAO.get_all()}

    def _weighted_average(self, values: list[MappedValue]) -> float:
        total_weight = sum(v.weight for v in values)
        if total_weight == 0:
            return 0.0
        return sum(v.computed_contribution * v.weight for v in values) / total_weight

    def _determine_status(self, computed: float, target: float,
                          higher_is_better: int) -> str:
        if target == 0:
            return "on_track"
        ratio = computed / target
        if higher_is_better:
            th = THRESHOLDS["higher"]
            if ratio >= th["green"]:  return "on_track"
            if ratio >= th["amber"]:  return "at_risk"
            return "off_track"
        else:
            th = THRESHOLDS["lower"]
            if ratio <= th["green"]:  return "on_track"
            if ratio <= th["amber"]:  return "at_risk"
            return "off_track"

    def _compute_risk_exposure(self, project_id: int) -> tuple[float, str]:
        risks = RiskDAO.get_by_project(project_id)
        open_risks = [r for r in risks if r["status"] == "open"]
        score = sum(
            RISK_WEIGHTS.get(r["impact"], 1.0) * RISK_WEIGHTS.get(r["probability"], 1.0)
            for r in open_risks
        )
        score = round(score, 2)
        if score == 0:    status = "on_track"
        elif score <= 5:  status = "at_risk"
        else:             status = "off_track"
        return score, status

    def compute(self, project_id: int) -> ProjectScorecard:
        """Run the full KPI computation pipeline for a project."""
        grouped = self._mapper.summary(project_id)

        kpi_scores: list[KPIScore] = []

        for kpi_name, mapped_values in grouped.items():
            if not mapped_values:
                continue

            sample       = mapped_values[0]
            computed_val = self._weighted_average(mapped_values)
            target       = sample.target_value
            h_i_b        = sample.higher_is_better
            status       = self._determine_status(computed_val, target, h_i_b)

            kpi_scores.append(KPIScore(
                kpi_id               = sample.kpi_id,
                kpi_name             = kpi_name,
                category             = sample.category,
                computed_value       = round(computed_val, 2),
                target_value         = target,
                unit                 = sample.unit,
                status               = status,
                higher_is_better     = h_i_b,
                contributing_metrics = [mv.metric_name for mv in mapped_values],
            ))

        risk_score, risk_status = self._compute_risk_exposure(project_id)
        already_has_risk = any(s.kpi_name == "Risk Exposure Score" for s in kpi_scores)
        if not already_has_risk:
            risk_kpi_id = next(
                (k["kpi_id"] for k in self._kpis.values() if "Risk" in k["kpi_name"]), -1
            )
            kpi_scores.append(KPIScore(
                kpi_id               = risk_kpi_id,
                kpi_name             = "Risk Exposure Score",
                category             = "risk",
                computed_value       = risk_score,
                target_value         = 0.0,
                unit                 = "score",
                status               = risk_status,
                higher_is_better     = 0,
                contributing_metrics = ["open_high_risks", "open_medium_risks"],
                notes                = "Weighted sum of open risk severity × probability",
            ))

        on_track  = sum(1 for s in kpi_scores if s.status == "on_track")
        at_risk   = sum(1 for s in kpi_scores if s.status == "at_risk")
        off_track = sum(1 for s in kpi_scores if s.status == "off_track")

        if off_track > 0:         overall = "off_track"
        elif at_risk > on_track:  overall = "at_risk"
        else:                     overall = "on_track"

        return ProjectScorecard(
            project_id          = project_id,
            kpi_scores          = sorted(kpi_scores, key=lambda s: s.category),
            overall_status      = overall,
            on_track_count      = on_track,
            at_risk_count       = at_risk,
            off_track_count     = off_track,
            risk_exposure_score = risk_score,
        )
