"""
engine/mapping_engine.py
------------------------
Rule-based MetricMapper: reads metric_kpi_mapping rules from the DB
and translates raw technical metric values into KPI scores.

This is the core academic contribution — directly answers Research Question 1:
  "How can selected technical IT project metrics be mapped to predefined
   business performance indicators?"
"""

from __future__ import annotations
from dataclasses import dataclass, field
from database import KpiDAO, MetricDAO


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class MappingRule:
    """One row from metric_kpi_mapping joined with kpis."""
    mapping_id: int
    metric_name: str
    kpi_id: int
    kpi_name: str
    category: str
    formula: str
    weight: float
    unit: str
    target_value: float
    higher_is_better: int


@dataclass
class MappedValue:
    """Result of evaluating one mapping rule against live metric data."""
    kpi_id: int
    kpi_name: str
    category: str
    metric_name: str
    raw_metric_value: float
    computed_contribution: float  # formula result
    weight: float
    unit: str
    target_value: float
    higher_is_better: int


# ---------------------------------------------------------------------------
# Formula evaluator
# ---------------------------------------------------------------------------

class FormulaEvaluator:
    """
    Safe formula evaluator.
    Formulas are simple Python expressions with access to the metric context.

    Supported variables:
      - value            : the raw metric value
      - target           : the KPI target_value
      - planned_duration : from metrics dict (default 90)
      - total_milestones : from metrics dict (default 4)
      - total_bugs       : from metrics dict (default 20)
      - hours_planned    : from metrics dict (default 480)
      - hours_actual     : from metrics dict (default 0)

    Supported functions: round, min, max, abs
    """

    SAFE_BUILTINS = {
        "__builtins__": {},
        "round": round,
        "min": min,
        "max": max,
        "abs": abs,
    }

    def evaluate(self, formula: str, metric_value: float,
                 metrics: dict[str, float], target: float) -> float:
        context = {
            **self.SAFE_BUILTINS,
            "value":            metric_value,
            "target":           target,
            "planned_duration": metrics.get("planned_duration", 90.0),
            "total_milestones": metrics.get("total_milestones", 4.0),
            "total_bugs":       metrics.get("total_bugs", 20.0),
            "hours_planned":    metrics.get("hours_planned", 480.0),
            "hours_actual":     metrics.get("hours_actual", 0.0),
        }
        try:
            result = eval(formula, context)  # noqa: S307
            return float(result) if result is not None else 0.0
        except ZeroDivisionError:
            return 0.0
        except Exception as exc:
            raise ValueError(f"Formula evaluation failed for '{formula}': {exc}") from exc


# ---------------------------------------------------------------------------
# MetricMapper — the main class
# ---------------------------------------------------------------------------

class MetricMapper:
    """
    Loads mapping rules from the DB and evaluates them against a project's
    live metric snapshot to produce weighted KPI contributions.

    Usage:
        mapper = MetricMapper()
        results = mapper.map(project_id=1)
        for mv in results:
            print(mv.kpi_name, mv.computed_contribution)
    """

    def __init__(self):
        self._rules: list[MappingRule] = []
        self._evaluator = FormulaEvaluator()
        self._load_rules()

    def _load_rules(self) -> None:
        rows = KpiDAO.get_mapping_rules()
        self._rules = [
            MappingRule(
                mapping_id      = r["mapping_id"],
                metric_name     = r["metric_name"],
                kpi_id          = r["kpi_id"],
                kpi_name        = r["kpi_name"],
                category        = r["category"],
                formula         = r["formula"],
                weight          = r["weight"],
                unit            = r.get("unit", ""),
                target_value    = r.get("target_value") or 1.0,
                higher_is_better= r.get("higher_is_better", 1),
            )
            for r in rows
        ]

    def reload_rules(self) -> None:
        """Re-fetch rules from DB (call if mapping table is updated at runtime)."""
        self._load_rules()

    def map(self, project_id: int) -> list[MappedValue]:
        """
        Evaluate all applicable mapping rules for a given project.
        Returns one MappedValue per rule that has metric data available.
        """
        metrics = MetricDAO.get_latest_per_name(project_id)
        results: list[MappedValue] = []

        for rule in self._rules:
            raw_value = metrics.get(rule.metric_name)
            if raw_value is None:
                continue  # no data for this metric in this project

            contribution = self._evaluator.evaluate(
                formula       = rule.formula,
                metric_value  = raw_value,
                metrics       = metrics,
                target        = rule.target_value,
            )

            results.append(MappedValue(
                kpi_id                = rule.kpi_id,
                kpi_name              = rule.kpi_name,
                category              = rule.category,
                metric_name           = rule.metric_name,
                raw_metric_value      = raw_value,
                computed_contribution = contribution,
                weight                = rule.weight,
                unit                  = rule.unit,
                target_value          = rule.target_value,
                higher_is_better      = rule.higher_is_better,
            ))

        return results

    def summary(self, project_id: int) -> dict[str, list[MappedValue]]:
        """Group mapped values by KPI name for easy consumption."""
        mapped = self.map(project_id)
        grouped: dict[str, list[MappedValue]] = {}
        for mv in mapped:
            grouped.setdefault(mv.kpi_name, []).append(mv)
        return grouped
