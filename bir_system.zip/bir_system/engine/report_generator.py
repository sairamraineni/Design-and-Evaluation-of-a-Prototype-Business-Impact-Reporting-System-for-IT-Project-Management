"""
engine/report_generator.py
--------------------------
ReportBuilder: generates business-impact and technical HTML/PDF reports
using the ProjectScorecard from KPIEngine.

Two report modes:
  - "business_impact" : KPI-focused, executive language, no raw metrics
  - "technical"       : includes raw metric values for comparison studies
"""

from __future__ import annotations
import os
from datetime import datetime
from pathlib import Path
from jinja2 import Environment, FileSystemLoader, select_autoescape

from engine.kpi_engine import KPIEngine, ProjectScorecard, KPIScore
from database import ProjectDAO, TaskDAO, RiskDAO, MetricDAO, ReportDAO

TEMPLATE_DIR = Path(__file__).parent.parent / "templates"


STATUS_LABELS = {
    "on_track":  "On track",
    "at_risk":   "At risk",
    "off_track": "Off track",
}

STATUS_COLORS = {
    "on_track":  "#1D9E75",
    "at_risk":   "#BA7517",
    "off_track": "#E24B4A",
}

STATUS_BG = {
    "on_track":  "#EAF3DE",
    "at_risk":   "#FAEEDA",
    "off_track": "#FCEBEB",
}


class ReportBuilder:
    """
    Produces HTML (and optionally PDF) project reports.

    Usage:
        builder = ReportBuilder()
        html = builder.build(project_id=1, report_type="business_impact")
        builder.save_pdf(html, "output/report.pdf")
    """

    def __init__(self, template_dir: Path = TEMPLATE_DIR):
        self._engine = KPIEngine()
        self._env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            autoescape=select_autoescape(["html"]),
        )
        self._env.filters["status_label"] = lambda s: STATUS_LABELS.get(s, s)
        self._env.filters["status_color"] = lambda s: STATUS_COLORS.get(s, "#888")
        self._env.filters["status_bg"]    = lambda s: STATUS_BG.get(s, "#f5f5f5")
        self._env.filters["fmt_float"]    = lambda v: f"{v:.2f}" if v is not None else "—"
        self._env.filters["fmt_pct"]      = lambda v: f"{v:.1f}%" if v is not None else "—"

    def _gather_context(self, project_id: int, report_type: str,
                        generated_by: str) -> dict:
        project  = ProjectDAO.get_by_id(project_id)
        if not project:
            raise ValueError(f"Project {project_id} not found")

        scorecard = self._engine.compute(project_id)
        tasks     = TaskDAO.get_by_project(project_id)
        risks     = RiskDAO.get_by_project(project_id)
        metrics   = MetricDAO.get_latest_per_name(project_id) if report_type == "technical" else {}

        milestones = [t for t in tasks if t["milestone"]]
        completed_ms = sum(1 for m in milestones if m["status"] == "completed")

        return {
            "project":       project,
            "scorecard":     scorecard,
            "tasks":         tasks,
            "milestones":    milestones,
            "risks":         risks,
            "metrics":       metrics,
            "report_type":   report_type,
            "generated_by":  generated_by,
            "generated_at":  datetime.now().strftime("%d %B %Y, %H:%M"),
            "completed_ms":  completed_ms,
            "total_ms":      len(milestones),
            "STATUS_COLORS": STATUS_COLORS,
            "STATUS_BG":     STATUS_BG,
            "STATUS_LABELS": STATUS_LABELS,
        }

    def build(self, project_id: int,
              report_type: str = "business_impact",
              generated_by: str = "System") -> str:
        """Render and return the HTML report as a string."""
        ctx = self._gather_context(project_id, report_type, generated_by)

        template_name = (
            "report_business.html" if report_type == "business_impact"
            else "report_technical.html"
        )
        template = self._env.get_template(template_name)
        html = template.render(**ctx)

        report_id = ReportDAO.create(project_id, report_type, generated_by)
        kpi_rows = [
            {
                "kpi_id":        s.kpi_id,
                "computed_value": s.computed_value,
                "target_value":   s.target_value,
                "status":         s.status,
                "notes":          s.notes,
            }
            for s in ctx["scorecard"].kpi_scores
            if s.kpi_id > 0
        ]
        ReportDAO.save_kpi_values(report_id, kpi_rows)

        return html

    def save_html(self, html: str, path: str) -> None:
        """Write HTML report to disk."""
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(html, encoding="utf-8")
        print(f"[Report] HTML saved → {path}")

    def save_pdf(self, html: str, path: str) -> None:
        """Convert HTML to PDF using WeasyPrint (must be installed)."""
        try:
            from weasyprint import HTML as WP_HTML
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            WP_HTML(string=html).write_pdf(path)
            print(f"[Report] PDF saved → {path}")
        except ImportError:
            print("[Report] WeasyPrint not installed. Run: pip install weasyprint")
        except Exception as exc:
            print(f"[Report] PDF generation failed: {exc}")

    def build_and_save(self, project_id: int, output_dir: str = "output",
                       report_type: str = "business_impact",
                       generated_by: str = "System",
                       pdf: bool = False) -> str:
        """Convenience: build, save HTML (and optionally PDF)."""
        html = self.build(project_id, report_type, generated_by)
        project = ProjectDAO.get_by_id(project_id)
        slug = project["project_name"].lower().replace(" ", "_")
        ts   = datetime.now().strftime("%Y%m%d_%H%M")
        html_path = os.path.join(output_dir, f"{slug}_{report_type}_{ts}.html")
        self.save_html(html, html_path)
        if pdf:
            pdf_path = html_path.replace(".html", ".pdf")
            self.save_pdf(html, pdf_path)
        return html_path
