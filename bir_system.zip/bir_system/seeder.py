"""
seeder.py
---------
Populates the database with realistic simulated IT project data.
Run once after initialise_db() to get meaningful demo data.

Usage:
    python seeder.py              # seeds with default 3 projects
    python seeder.py --reset      # drops & recreates DB first
"""

import random
import sqlite3
import argparse
from datetime import date, timedelta
from database import (
    initialise_db, managed_connection, DB_PATH,
    ProjectDAO, TaskDAO, MetricDAO, RiskDAO
)


random.seed(42)


def random_date(start: date, end: date) -> str:
    delta = (end - start).days
    return (start + timedelta(days=random.randint(0, max(delta, 1)))).isoformat()


PROJECTS = [
    {
        "name": "CRM Platform Upgrade",
        "description": "Migrate legacy CRM to cloud-based SaaS solution with API integrations.",
        "start": date(2025, 1, 15),
        "end": date(2025, 6, 30),
        "manager": "Jane Smith",
        "budget": 150_000.0,
        "status": "active",
    },
    {
        "name": "Data Warehouse Migration",
        "description": "Move on-premise data warehouse to AWS Redshift for analytics scalability.",
        "start": date(2024, 9, 1),
        "end": date(2025, 3, 31),
        "manager": "Raj Patel",
        "budget": 220_000.0,
        "status": "completed",
    },
    {
        "name": "Mobile App Redesign",
        "description": "Full UI/UX overhaul of the customer-facing mobile application.",
        "start": date(2025, 3, 1),
        "end": date(2025, 9, 30),
        "manager": "Amara Osei",
        "budget": 95_000.0,
        "status": "active",
    },
]

TASK_TEMPLATES = [
    ("Requirements Gathering",   0,  16,  True,  100.0, "completed",   1),
    ("System Design",            14, 28,  True,  100.0, "completed",   1),
    ("Backend Development",      28, 84,  False,  65.0, "in_progress", 0),
    ("Frontend Development",     56, 98,  False,  40.0, "in_progress", 0),
    ("QA & Testing",             84, 112, False,   0.0, "not_started", 0),
    ("User Acceptance Testing", 105, 126, False,   0.0, "not_started", 1),
    ("Deployment & Go Live",    126, 133, False,   0.0, "not_started", 1),
]

RISKS = [
    ("Legacy data migration complexity may cause delays",    "high",   "high",   "open",      "Allocate dedicated migration sprint; run parallel systems"),
    ("Third-party API availability and SLA compliance",      "medium", "medium", "mitigated", "Use mock APIs during development; contractual SLA in place"),
    ("Scope creep from business stakeholders",               "medium", "high",   "open",      "Strict change control board; weekly scope review"),
    ("Key resource unavailability due to illness/departure", "low",    "high",   "open",      "Cross-train team; maintain runbooks for critical components"),
    ("Integration failures with downstream systems",         "medium", "medium", "open",      "Early integration testing; contract with vendor support"),
]

METRIC_TEMPLATES = {
    "budget_spent_pct":         (38.0,  55.0,  "percent", "Finance System"),
    "test_coverage_pct":        (55.0,  82.0,  "percent", "CI Pipeline"),
    "schedule_variance_days":   (-5.0,   2.0,  "days",    "Jira"),
    "open_high_risks":          (1.0,    3.0,  "count",   "Risk Register"),
    "open_medium_risks":        (1.0,    4.0,  "count",   "Risk Register"),
    "milestones_on_time":       (1.0,    3.0,  "count",   "Jira"),
    "total_milestones":         (4.0,    4.0,  "count",   "Jira"),
    "bugs_resolved_on_time":    (8.0,   18.0,  "count",   "Jira"),
    "total_bugs":               (12.0,  22.0,  "count",   "Jira"),
    "hours_actual":             (320.0, 600.0, "hours",   "Timesheets"),
    "hours_planned":            (480.0, 480.0, "hours",   "Project Plan"),
    "planned_duration":         (90.0,  90.0,  "days",    "Project Plan"),
}


def seed_resources(conn: sqlite3.Connection) -> list[int]:
    resources = [
        ("Alice Nguyen",   "Backend Developer",  "Engineering",   75.0),
        ("Bob Patel",      "QA Engineer",        "Engineering",   60.0),
        ("Carol Wright",   "Business Analyst",   "PMO",           65.0),
        ("David Kim",      "Frontend Developer", "Engineering",   72.0),
        ("Fatima Hassan",  "DevOps Engineer",    "Engineering",   80.0),
        ("George Turner",  "Project Manager",    "PMO",           90.0),
        ("Priya Sharma",   "Data Engineer",      "Data",          78.0),
    ]
    ids = []
    for name, role, dept, rate in resources:
        cur = conn.execute(
            "INSERT OR IGNORE INTO resources (name, role, department, hourly_rate) VALUES (?,?,?,?)",
            (name, role, dept, rate)
        )
        if cur.lastrowid:
            ids.append(cur.lastrowid)
    existing = conn.execute("SELECT resource_id FROM resources").fetchall()
    return [r[0] for r in existing]


def seed_project(conn: sqlite3.Connection, proj: dict, resource_ids: list[int]) -> int:
    cur = conn.execute(
        """INSERT INTO projects
           (project_name, description, start_date, end_date, status, project_manager, budget)
           VALUES (?,?,?,?,?,?,?)""",
        (proj["name"], proj["description"],
         proj["start"].isoformat(), proj["end"].isoformat(),
         proj["status"], proj["manager"], proj["budget"])
    )
    pid = cur.lastrowid

    for (tname, s_off, e_off, started, pct, tstatus, milestone) in TASK_TEMPLATES:
        p_start = (proj["start"] + timedelta(days=s_off)).isoformat()
        p_end   = (proj["start"] + timedelta(days=e_off)).isoformat()
        a_start = (proj["start"] + timedelta(days=s_off + random.randint(0, 2))).isoformat() if started else None
        a_end   = (proj["start"] + timedelta(days=e_off - random.randint(0, 3))).isoformat() if pct == 100.0 else None
        cur2 = conn.execute(
            """INSERT INTO tasks
               (project_id, task_name, planned_start, planned_end, actual_start,
                actual_end, completion_pct, status, milestone)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (pid, tname, p_start, p_end, a_start, a_end, pct, tstatus, milestone)
        )
        task_id = cur2.lastrowid
        assigned = random.sample(resource_ids, k=min(2, len(resource_ids)))
        for rid in assigned:
            h_planned = round(random.uniform(40, 120), 1)
            h_actual  = round(h_planned * (pct / 100) * random.uniform(0.85, 1.15), 1) if pct > 0 else 0.0
            conn.execute(
                """INSERT INTO task_resource_usage
                   (task_id, resource_id, hours_planned, hours_actual)
                   VALUES (?,?,?,?)""",
                (task_id, rid, h_planned, h_actual)
            )

    for (desc, prob, impact, status, mitigation) in RISKS[:random.randint(3, 5)]:
        conn.execute(
            """INSERT INTO risks
               (project_id, description, probability, impact, status, mitigation_plan)
               VALUES (?,?,?,?,?,?)""",
            (pid, desc, prob, impact, status, mitigation)
        )

    for mname, (lo, hi, unit, source) in METRIC_TEMPLATES.items():
        value = round(random.uniform(lo, hi), 1)
        conn.execute(
            """INSERT INTO technical_metrics
               (project_id, metric_name, metric_value, unit, source)
               VALUES (?,?,?,?,?)""",
            (pid, mname, value, unit, source)
        )

    return pid


def seed_all(db_path: str = DB_PATH, reset: bool = False) -> None:
    if reset:
        import os
        if os.path.exists(db_path):
            os.remove(db_path)
        print(f"[Seeder] Removed existing DB: {db_path}")
        initialise_db(db_path)
    elif not os.path.exists(db_path):
        initialise_db(db_path)
    else:
        print(f"[Seeder] Using existing DB: {db_path}")

    with managed_connection(db_path) as conn:
        resource_ids = seed_resources(conn)
        print(f"[Seeder] {len(resource_ids)} resources ready")

        existing = conn.execute("SELECT COUNT(*) FROM projects").fetchone()[0]
        if existing > 0 and not reset:
            print(f"[Seeder] {existing} projects already exist — skipping seed. Use --reset to reseed.")
            return

        for proj in PROJECTS:
            pid = seed_project(conn, proj, resource_ids)
            print(f"[Seeder] Created project [{pid}]: {proj['name']}")

    print("[Seeder] Done — database is ready.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Seed the BIR database with demo data")
    parser.add_argument("--reset", action="store_true", help="Drop and recreate the database first")
    parser.add_argument("--db",    default=DB_PATH,    help="Path to SQLite database file")
    args = parser.parse_args()
    seed_all(db_path=args.db, reset=args.reset)
